import {
    DynamoDBClient,
    PutItemCommand,
    ScanCommand,
    DeleteItemCommand,
    UpdateItemCommand
  } from "@aws-sdk/client-dynamodb";
  
  const client = new DynamoDBClient({ region: "us-east-2" });
  
  const BASE_URL = "https://suvegwrmzl.execute-api.us-east-2.amazonaws.com";
  
  // ================= TOKEN SYSTEM =================
  function generateToken(username) {
    return Buffer.from(username).toString("base64");
  }
  
  function verifyToken(event) {
    const auth = event.headers?.authorization || event.headers?.Authorization;
    if (!auth) return null;
  
    const token = auth.startsWith("Bearer ")
      ? auth.split(" ")[1]
      : auth;
  
    try {
      return Buffer.from(token, "base64").toString("utf-8");
    } catch {
      return null;
    }
  }
  
  // ================= SLUG =================
  function generateSlug(length = 6) {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let slug = "";
    for (let i = 0; i < length; i++) {
      slug += chars[Math.floor(Math.random() * chars.length)];
    }
    return slug;
  }
  
  // ================= CORS =================
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS"
  };
  
  export const handler = async (event) => {
  
    const method = event.requestContext?.http?.method;
    const path = event.rawPath || "/";
    const cleanPath = path.replace(/^\/+/, ""); // remove leading /
  
    // ================= OPTIONS =================
    if (method === "OPTIONS") {
      return {
        statusCode: 200,
        headers: cors
      };
    }
  
    try {
  
      // ================= LOGIN =================
      if (method === "POST" && path === "/login") {
  
        const body = JSON.parse(event.body || "{}");
  
        if (body.username === "admin" && body.password === "admin") {
  
          const token = generateToken(body.username);
  
          return {
            statusCode: 200,
            headers: cors,
            body: JSON.stringify({ token })
          };
        }
  
        return {
          statusCode: 401,
          headers: cors,
          body: JSON.stringify({ error: "Invalid login" })
        };
      }
  
      // ================= PUBLIC REDIRECT =================
      // 🔥 Only trigger if NOT API route
      const isApiRoute =
        path === "/login" ||
        path === "/create" ||
        path === "/list" ||
        path === "/delete";
  
      if (method === "GET" && !isApiRoute && cleanPath) {
  
        const slug = cleanPath;
  
        const result = await client.send(new UpdateItemCommand({
          TableName: "redirects",
          Key: { slug: { S: slug } },
          UpdateExpression: "SET clicks = if_not_exists(clicks, :z) + :i",
          ExpressionAttributeValues: {
            ":i": { N: "1" },
            ":z": { N: "0" }
          },
          ReturnValues: "ALL_NEW"
        }));
  
        const url = result.Attributes?.url?.S;
  
        if (url && url.startsWith("http")) {
          return {
            statusCode: 302,
            headers: { Location: url }
          };
        }
  
        return {
          statusCode: 404,
          headers: cors,
          body: "Not found"
        };
      }
  
      // ================= AUTH =================
      const user = verifyToken(event);
  
      if (!user) {
        return {
          statusCode: 401,
          headers: cors,
          body: JSON.stringify({ error: "Unauthorized" })
        };
      }
  
      // ================= CREATE =================
      if (method === "POST" && path === "/create") {
  
        const body = JSON.parse(event.body || "{}");
  
        if (!body.url || !body.url.startsWith("http")) {
          return {
            statusCode: 400,
            headers: cors,
            body: JSON.stringify({ error: "Invalid URL" })
          };
        }
  
        const slug = generateSlug();
  
        await client.send(new PutItemCommand({
          TableName: "redirects",
          Item: {
            slug: { S: slug },
            url: { S: body.url },
            clicks: { N: "0" },
            user: { S: user }
          }
        }));
  
        return {
          statusCode: 200,
          headers: cors,
          body: JSON.stringify({
            link: `${BASE_URL}/${slug}`
          })
        };
      }
  
      // ================= LIST =================
      if (method === "GET" && path === "/list") {
  
        const result = await client.send(new ScanCommand({
          TableName: "redirects"
        }));
  
        const items = (result.Items || [])
          .filter(i => i.user?.S === user)
          .map(i => ({
            slug: i.slug?.S || "",
            url: i.url?.S || "",
            clicks: Number(i.clicks?.N || 0)
          }));
  
        return {
          statusCode: 200,
          headers: cors,
          body: JSON.stringify({ items })
        };
      }
  
      // ================= DELETE =================
      if (method === "POST" && path === "/delete") {
  
        const body = JSON.parse(event.body || "{}");
  
        if (!body.slug) {
          return {
            statusCode: 400,
            headers: cors,
            body: JSON.stringify({ error: "slug required" })
          };
        }
  
        await client.send(new DeleteItemCommand({
          TableName: "redirects",
          Key: { slug: { S: body.slug } }
        }));
  
        return {
          statusCode: 200,
          headers: cors,
          body: JSON.stringify({ success: true })
        };
      }
  
      return {
        statusCode: 404,
        headers: cors,
        body: "Route not found"
      };
  
    } catch (err) {
      console.error("ERROR:", err);
  
      return {
        statusCode: 500,
        headers: cors,
        body: err.message
      };
    }
  };