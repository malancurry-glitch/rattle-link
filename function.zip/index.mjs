import {
  DynamoDBClient,
  PutItemCommand,
  ScanCommand,
  DeleteItemCommand,
  UpdateItemCommand,
  GetItemCommand
} from "@aws-sdk/client-dynamodb";

import crypto from "crypto";

const client = new DynamoDBClient({ region: "us-east-2" });

const BASE_URL = "https://suvegwrmzl.execute-api.us-east-2.amazonaws.com";
const SECRET = "my-secret";

// ================= HASH =================
function hash(password) {
  return crypto.createHash("sha256").update(password).digest("hex");
}

// ================= TOKEN =================
function generateToken(username) {
  return Buffer.from(username + ":" + SECRET).toString("base64");
}

function verifyToken(event) {
  const auth = event.headers?.authorization || event.headers?.Authorization;
  if (!auth) return null;

  const token = auth.startsWith("Bearer ")
    ? auth.split(" ")[1]
    : auth;

  try {
    const [user, sec] = Buffer.from(token, "base64").toString().split(":");
    if (sec !== SECRET) return null;
    return user;
  } catch {
    return null;
  }
}

// ================= SLUG =================
function generateSlug() {
  return Math.random().toString(36).substring(2, 8);
}

// ================= CORS =================
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "*",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS"
};

// ================= HANDLER =================
export const handler = async (event) => {

  console.log("🔥 RUNNING NEW CODE");

  const method = event.requestContext?.http?.method || "GET";

  let path =
    event.requestContext?.http?.path ||
    event.rawPath ||
    event.path ||
    "/";

  path = path.toLowerCase();

  if (method === "OPTIONS") {
    return { statusCode: 200, headers: cors };
  }

  try {

    // ================= SIGNUP =================
    if (method === "POST" && path.includes("signup")) {

      const body = JSON.parse(event.body || "{}");

      if (!body.username || !body.password) {
        return {
          statusCode: 400,
          headers: cors,
          body: JSON.stringify({ error: "Missing fields" })
        };
      }

      await client.send(new PutItemCommand({
        TableName: "users",
        Item: {
          username: { S: body.username },
          password: { S: hash(body.password) }
        }
      }));

      return {
        statusCode: 200,
        headers: cors,
        body: JSON.stringify({ success: true })
      };
    }

    // ================= LOGIN =================
    if (method === "POST" && path.includes("login")) {

      const body = JSON.parse(event.body || "{}");

      const res = await client.send(new GetItemCommand({
        TableName: "users",
        Key: { username: { S: body.username } }
      }));

      if (!res.Item) {
        return { statusCode: 401, headers: cors, body: "User not found" };
      }

      if (res.Item.password.S !== hash(body.password)) {
        return { statusCode: 401, headers: cors, body: "Wrong password" };
      }

      return {
        statusCode: 200,
        headers: cors,
        body: JSON.stringify({ token: generateToken(body.username) })
      };
    }

    // ================= REDIRECT =================
    if (
      method === "GET" &&
      !path.includes("create") &&
      !path.includes("list") &&
      !path.includes("delete") &&
      !path.includes("login") &&
      !path.includes("signup")
    ) {

      const slug = path.split("/").pop();

      const res = await client.send(new UpdateItemCommand({
        TableName: "redirects",
        Key: { slug: { S: slug } },
        UpdateExpression: "SET clicks = if_not_exists(clicks, :z) + :i",
        ExpressionAttributeValues: {
          ":i": { N: "1" },
          ":z": { N: "0" }
        },
        ReturnValues: "ALL_NEW"
      }));

      const url = res.Attributes?.url?.S;

      if (url) {
        return { statusCode: 302, headers: { Location: url } };
      }

      return { statusCode: 404, body: "Not found" };
    }

    // ================= AUTH =================
    const user = verifyToken(event);
    if (!user) return { statusCode: 401, headers: cors, body: "Unauthorized" };

    // ================= CREATE =================
    if (method === "POST" && path.includes("create")) {

      const body = JSON.parse(event.body || {});
      const slug = generateSlug();

      await client.send(new PutItemCommand({
        TableName: "redirects",
        Item: {
          slug: { S: slug },
          url: { S: body.url },
          clicks: { N: "0" },
          user: { S: user }
        }
      }));

      return {
        statusCode: 200,
        headers: cors,
        body: JSON.stringify({ link: `${BASE_URL}/${slug}` })
      };
    }

    // ================= LIST =================
    if (method === "GET" && path.includes("list")) {

      const res = await client.send(new ScanCommand({
        TableName: "redirects"
      }));

      const items = (res.Items || [])
        .filter(i => i.user?.S === user)
        .map(i => ({
          slug: i.slug.S,
          url: i.url.S,
          clicks: Number(i.clicks.N)
        }));

      return {
        statusCode: 200,
        headers: cors,
        body: JSON.stringify({ items })
      };
    }

    // ================= DELETE =================
    if (method === "POST" && path.includes("delete")) {

      const body = JSON.parse(event.body || {});

      await client.send(new DeleteItemCommand({
        TableName: "redirects",
        Key: { slug: { S: body.slug } }
      }));

      return { statusCode: 200, headers: cors, body: "deleted" };
    }

    return { statusCode: 404, body: "Route not found" };

  } catch (err) {
    console.error("ERROR:", err);
    return { statusCode: 500, headers: cors, body: err.message };
  }
};